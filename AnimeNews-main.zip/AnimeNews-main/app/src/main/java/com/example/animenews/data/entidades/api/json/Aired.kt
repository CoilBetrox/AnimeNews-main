package com.example.animenews.data.entidades.api.json

data class Aired(
    val from: String,
    val prop: Prop,
    val string: String,
    val to: String
)