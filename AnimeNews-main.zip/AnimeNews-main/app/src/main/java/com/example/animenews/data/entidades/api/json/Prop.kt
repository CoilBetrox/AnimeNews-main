package com.example.animenews.data.entidades.api.json

data class Prop(
    val from: From,
    val to: To
)