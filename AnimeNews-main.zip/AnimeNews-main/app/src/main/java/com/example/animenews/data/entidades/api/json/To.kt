package com.example.animenews.data.entidades.api.json

data class To(
    val day: Int,
    val month: Int,
    val year: Int
)