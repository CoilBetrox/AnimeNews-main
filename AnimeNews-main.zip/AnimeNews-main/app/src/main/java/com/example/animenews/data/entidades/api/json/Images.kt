package com.example.animenews.data.entidades.api.json

data class Images(
    val jpg: Jpg,
    val webp: Webp
)