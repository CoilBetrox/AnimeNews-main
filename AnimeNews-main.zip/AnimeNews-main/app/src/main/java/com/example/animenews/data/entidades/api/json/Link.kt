package com.example.animenews.data.entidades.api.json

data class Link(
    val active: Boolean,
    val label: String,
    val url: String
)