package com.example.animenews.data.entidades.api.json

data class Links(
    val first: String,
    val last: String,
    val next: String,
    val prev: Any
)