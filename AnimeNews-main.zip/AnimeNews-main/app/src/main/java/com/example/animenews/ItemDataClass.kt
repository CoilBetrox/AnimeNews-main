package com.example.animenews

data class ItemDataClass(val id: Int, var photo: Int , var name: String )