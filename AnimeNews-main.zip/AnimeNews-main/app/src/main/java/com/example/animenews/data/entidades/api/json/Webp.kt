package com.example.animenews.data.entidades.api.json

data class Webp(
    val image_url: String,
    val large_image_url: String,
    val small_image_url: String
)