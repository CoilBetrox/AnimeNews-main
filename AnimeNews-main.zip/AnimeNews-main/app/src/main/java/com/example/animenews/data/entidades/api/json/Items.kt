package com.example.animenews.data.entidades.api.json

data class Items(
    val count: Int,
    val per_page: Int,
    val total: Int
)