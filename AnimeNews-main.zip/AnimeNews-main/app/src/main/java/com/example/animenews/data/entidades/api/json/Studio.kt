package com.example.animenews.data.entidades.api.json

data class Studio(
    val mal_id: Int,
    val name: String,
    val type: String,
    val url: String
)