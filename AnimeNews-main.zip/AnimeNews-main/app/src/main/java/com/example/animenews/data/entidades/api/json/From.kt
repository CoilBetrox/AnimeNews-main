package com.example.animenews.data.entidades.api.json

data class From(
    val day: Int,
    val month: Int,
    val year: Int
)