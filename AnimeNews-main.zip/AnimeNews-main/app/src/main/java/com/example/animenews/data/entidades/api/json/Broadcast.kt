package com.example.animenews.data.entidades.api.json

data class Broadcast(
    val day: String,
    val string: String,
    val time: String,
    val timezone: String
)