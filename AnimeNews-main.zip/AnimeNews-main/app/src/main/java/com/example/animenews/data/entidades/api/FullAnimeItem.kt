package com.example.animenews.data.entidades.api

import com.example.animenews.data.entidades.api.json.Data

data class FullAnimeItem(
    val `data`: Data
)